package com.droidad.hackathon.project_inventory;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import com.github.nkzawa.emitter.Emitter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static com.droidad.hackathon.project_inventory.SplashScreenActivity.mSocket;

public class HomeActivity extends AppCompatActivity {

    ImageButton DropdownButton, AddButton, NotificationButton, AccountButton;
    ListView IdeasListview;

    IdeasListData ideasListData;
    IdeasListAdapter ideasListAdapter;
    ProgressDialog progressDialog;

    boolean dropdown_selected=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        DropdownButton=(ImageButton) findViewById(R.id.dropdown_button);
        AddButton=(ImageButton) findViewById(R.id.add_button);
        NotificationButton=(ImageButton)findViewById(R.id.notifications_button);
        AccountButton=(ImageButton)findViewById(R.id.account_button);
        IdeasListview=(ListView)findViewById(R.id.ideas_listview);

        final List<IdeasListData> ideasList = new ArrayList<IdeasListData>();
        ideasListAdapter=new IdeasListAdapter(this, R.layout.ideas_list_layout, ideasList);
        IdeasListview.setAdapter(ideasListAdapter);


        DropdownButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(dropdown_selected)
                {
                    AddButton.setVisibility(View.INVISIBLE);
                    NotificationButton.setVisibility(View.INVISIBLE);
                    AccountButton.setVisibility(View.INVISIBLE);
                    dropdown_selected=false;
                }
                else
                {

                    AddButton.setVisibility(View.VISIBLE);
                    NotificationButton.setVisibility(View.VISIBLE);
                    AccountButton.setVisibility(View.VISIBLE);
                    dropdown_selected=true;

                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            /*runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    //progressDialog.create();
                                    progressDialog.setMessage("Please, wait content is Loading");
                                    progressDialog.setTitle("Loading");
                                    progressDialog.setCancelable(false);
                                    progressDialog.show();
                                }
                            });*/
                            mSocket.emit("projects_table_retrive");
                            mSocket.on("projects_table_retrive_response", new Emitter.Listener() {
                                @Override
                                public void call(Object... args) {
                                    System.out.println("Response: "+String.valueOf(args[0]));
                                    /*JSONArray jsonArray = (JSONArray)args[0];
                                    if(jsonArray.length()==0)
                                    {
                                        runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                progressDialog.setCancelable(true);
                                                progressDialog.cancel();
                                                Toast.makeText(getApplicationContext(), "There is no Data Availabe", Toast.LENGTH_SHORT).show();
                                            }
                                        });
                                    }
                                    try {


                                        for(int i =0;i<jsonArray.length();i++)
                                        {
                                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                                            System.out.println("username: "+jsonObject.getString("username"));
                                            //ideasListAdapter.add(new IdeasListData(jsonObject.getString("team_image"),jsonObject.getString("team_name"),jsonObject.getString("team_id")));
                                        }
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                    /*finally {
                                        runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                ideasListAdapter.notifyDataSetChanged();
                                                progressDialog.setCancelable(true);
                                                progressDialog.cancel();
                                            }
                                        });

                                    }*/
                                }
                            });
                        }
                    }).start();


                }
            }
        });

        AddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, AddProjectActivity.class));
            }
        });

        NotificationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, NotificationActivity.class));
            }
        });

        AccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, AccountActivity.class));
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.homescreen_menu, menu);


        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.home_search_button) {
            startActivity(new Intent(HomeActivity.this, SearchActivity.class));
        }

        return super.onOptionsItemSelected(item);

    }
}
