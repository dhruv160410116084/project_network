package com.droidad.hackathon.project_inventory;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.github.nkzawa.emitter.Emitter;

import static com.droidad.hackathon.project_inventory.SplashScreenActivity.mSocket;


public class LoginActivity extends AppCompatActivity {

    EditText MobileNoEdittext, PasswordEdittext;
    TextView SignupTextview;
    Button LoginButton;

    static String MobileNo="";
    static String userId="";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        MobileNoEdittext=(EditText)findViewById(R.id.mobile_no_edittext);
        PasswordEdittext=(EditText)findViewById(R.id.password_edittext);
        LoginButton=(Button)findViewById(R.id.login_button);
        SignupTextview=(TextView)findViewById(R.id.signup_textview);

        LoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(MobileNoEdittext.getText().length()==0 && PasswordEdittext.getText().length()==0)
                {
                    MobileNoEdittext.setError("Enter Mobile No");
                    PasswordEdittext.setError("Enter Password");
                }
                else if (MobileNoEdittext.getText().length()==0)
                {
                    MobileNoEdittext.setError("Enter Mobile No");
                }
                else if (PasswordEdittext.getText().length()==0)
                {
                    PasswordEdittext.setError("Enter Password");
                }
                else
                {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            mSocket.emit("user_login", MobileNoEdittext.getText().toString().trim(), PasswordEdittext.getText().toString().trim());
                            mSocket.on("user_login_response", new Emitter.Listener() {
                                @Override
                                public void call(final Object... args) {
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            Toast.makeText(getApplicationContext(), String.valueOf(args[0]), Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                    if(String.valueOf(args[0]).equals("false")){

                                        runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                Toast.makeText(getApplicationContext(), "Not Logged In", Toast.LENGTH_SHORT).show();
                                            }
                                        });

                                    }
                                    else {
                                        MobileNo=MobileNoEdittext.getText().toString().trim();
                                        userId=String.valueOf(args[0]);
                                        Intent intent=new Intent(LoginActivity.this, HomeActivity.class);
                                        startActivity(intent);
                                    }
                                }
                            });
                        }
                    }).start();

                }


            }
        });

        SignupTextview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, UserDetailsActivity.class));
            }
        });



    }
}
