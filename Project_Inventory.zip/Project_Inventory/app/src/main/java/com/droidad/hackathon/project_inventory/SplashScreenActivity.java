package com.droidad.hackathon.project_inventory;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.github.nkzawa.socketio.client.IO;
import com.github.nkzawa.socketio.client.Socket;
import java.net.URISyntaxException;
import java.util.Calendar;
import java.util.Date;

public class SplashScreenActivity extends AppCompatActivity {

    static Socket mSocket;
    ProgressBar SplashProgressBar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_screen);

        SplashProgressBar=(ProgressBar)findViewById(R.id.splash_progressbar);

        try {
            mSocket = IO.socket("http://stupid-lionfish-85.localtunnel.me");

        } catch (
                URISyntaxException e) {
            Toast.makeText(this, "Connection Error", Toast.LENGTH_SHORT).show();
        }

        mSocket.connect();
        Toast.makeText(this, "Connected", Toast.LENGTH_SHORT).show();
        Date currentTime = Calendar.getInstance().getTime();
        Toast.makeText(this, currentTime.toString(), Toast.LENGTH_SHORT).show();
        startActivity(new Intent(SplashScreenActivity.this, LoginActivity.class));
    }
}
