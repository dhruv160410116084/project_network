package com.droidad.hackathon.project_inventory;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import java.net.URL;
import java.util.List;

import static com.droidad.hackathon.project_inventory.UserDetailsActivity.decodeImage;

public class IdeasListAdapter extends ArrayAdapter<IdeasListData> {

    List<IdeasListData> objects;



    public IdeasListAdapter(@NonNull Context context, int resource, @NonNull List<IdeasListData> objects) {
        super(context, resource, objects);
        this.objects = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = ((Activity) getContext()).getLayoutInflater().inflate(R.layout.ideas_list_layout, parent, false);
        }

        IdeasListData ideasListData=getItem(position);

        ImageView UserImageview=(ImageView)convertView.findViewById(R.id.user_imageview);

        UserImageview.setImageBitmap(decodeImage(ideasListData.getProjectDocument()));

        TextView UsernameTextview=(TextView)convertView.findViewById(R.id.username_textview);
        UsernameTextview.setText(ideasListData.getUserName());

        TextView ProjectnameTextview=(TextView)convertView.findViewById(R.id.projectname_textview);
        ProjectnameTextview.setText(ideasListData.getProjectName());


        /*if(ideasListData.getProjectDocumentType().equals("Video")){

            ImageView ProjectImageview=(ImageView)convertView.findViewById(R.id.project_imageview);
            ProjectImageview.setVisibility(View.INVISIBLE);

            VideoView ProjectVideoView=(VideoView)convertView.findViewById(R.id.project_videoview);
            ProjectVideoView.setVisibility(View.VISIBLE);
            //Picasso.get().load(ideasListData.getProjectDocumentLink()).into((Target) ProjectVideoView);
            final MediaController mediacontroller = new MediaController(getContext());
            mediacontroller.setAnchorView(ProjectVideoView);


            ProjectVideoView.setMediaController(mediacontroller);
            ProjectVideoView.setVideoURI(Uri.parse(ideasListData.getProjectDocumentLink()));
            ProjectVideoView.requestFocus();
            ProjectVideoView.start();

            ProjectVideoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    Toast.makeText(getContext(), "Video over", Toast.LENGTH_SHORT).show();

                }
            });

            ProjectVideoView.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer mp, int what, int extra) {
                    Log.d("API123", "What " + what + " extra " + extra);
                    return false;
                }
            });
        }
        else */if(ideasListData.getProjectDocumentType().equals("Image")){

            //VideoView ProjectVideoView=(VideoView)convertView.findViewById(R.id.project_videoview);
            //ProjectVideoView.setVisibility(View.INVISIBLE);

            ImageView ProjectImageview=(ImageView)convertView.findViewById(R.id.project_imageview);
            //ProjectImageview.setVisibility(View.VISIBLE);
            ProjectImageview.setImageBitmap(decodeImage(ideasListData.getProjectDocument()));
        }

        TextView Intrestedpeople_Textview=(TextView)convertView.findViewById(R.id.intrested_people_textview);
        Intrestedpeople_Textview.setText("Intrested People: "+ideasListData.getIntrestedPeopleCount());

        return convertView;
    }


    @Nullable
    @Override
    public IdeasListData getItem(int position) {
        return objects.get(position);
    }

    @Override
    public int getCount() {
        return objects.size();
    }
}
