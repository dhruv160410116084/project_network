package com.droidad.hackathon.project_inventory;

import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.github.nkzawa.emitter.Emitter;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import static com.droidad.hackathon.project_inventory.SplashScreenActivity.mSocket;


public class UserDetailsActivity extends AppCompatActivity {

    EditText UserNameEdittext, CollegeNameEdittext, CityNameEditText, PhoneNoEditText, EmailIDEdittext, PasswordEdittext, ConfirmPasswordEdittext;
    Button AddImageButton, SubmitButton;
    Spinner FieldSpinner;

    ProgressDialog progressDialog;

    String imgDecodableString="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_details);

        UserNameEdittext = (EditText) findViewById(R.id.username_edittext);
        CollegeNameEdittext = (EditText) findViewById(R.id.collegename_edittext);
        CityNameEditText = (EditText) findViewById(R.id.cityname_edittext);
        PhoneNoEditText = (EditText) findViewById(R.id.phoneno_edittext);
        EmailIDEdittext = (EditText) findViewById(R.id.emailid_edittext);
        AddImageButton = (Button) findViewById(R.id.add_image_button);
        FieldSpinner = (Spinner) findViewById(R.id.field_spinner);
        SubmitButton = (Button) findViewById(R.id.submit_button);
        PasswordEdittext=(EditText)findViewById(R.id.password_edittext);
        ConfirmPasswordEdittext=(EditText)findViewById(R.id.confirm_password_edittext);


        String[] FieldList = {"IT", "Comp", "Mech"};
        ArrayAdapter<String> FieldAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, FieldList);
        FieldAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        FieldSpinner.setAdapter(FieldAdapter);


        AddImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                openGallery();

            }

        });


        SubmitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        mSocket.emit("user_register", UserNameEdittext.getText().toString().trim(), CollegeNameEdittext.getText().toString().trim(),
                                CityNameEditText.getText().toString().trim(), PhoneNoEditText.getText().toString().trim(), EmailIDEdittext.getText().toString().trim(),
                                FieldSpinner.getSelectedItem().toString().trim(), PasswordEdittext.getText().toString().trim(),
                                encodeImage(imgDecodableString));
                        mSocket.on("user_register_response", new Emitter.Listener() {
                            @Override
                            public void call(final Object... args) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(getApplicationContext(), String.valueOf(args[0]), Toast.LENGTH_SHORT).show();
                                    }
                                });

                            }
                        });
                    }
                }).start();
            }
        });

    }

    private void openGallery()
    {
        Intent galleryintent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(galleryintent, 1);
    }

    @Override
    protected void onActivityResult(int requestCode,int resultCode,Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK
                && null != data) {
            Uri selectedImage = data.getData();
            String[] filePathColumn = {MediaStore.Images.Media.DATA};

            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            // Move to first row
            cursor.moveToFirst();
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            imgDecodableString = cursor.getString(columnIndex);
            cursor.close();
            System.out.println("onActivityResult"+imgDecodableString);
            //sendImage(imgDecodableString);
        }
    }

    public static String encodeImage(String path)
    {
        File imagefile = new File(path);
        FileInputStream fis = null;
        try{
            fis = new FileInputStream(imagefile);
        }catch(FileNotFoundException e){
            e.printStackTrace();
        }
        Bitmap bm = BitmapFactory.decodeStream(fis);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.JPEG,100,baos);
        byte[] b = baos.toByteArray();
        String encImage = Base64.encodeToString(b, Base64.DEFAULT);
        //Base64.de
        return encImage;

    }

    public static Bitmap decodeImage(String data)
    {
        byte[] b = Base64.decode(data,Base64.DEFAULT);
        Bitmap bmp = BitmapFactory.decodeByteArray(b,0,b.length);
        return bmp;
    }

}
