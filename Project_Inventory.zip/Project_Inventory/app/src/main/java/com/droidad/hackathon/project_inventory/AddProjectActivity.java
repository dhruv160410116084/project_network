package com.droidad.hackathon.project_inventory;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.github.nkzawa.emitter.Emitter;

import java.util.Calendar;

import static com.droidad.hackathon.project_inventory.LoginActivity.userId;
import static com.droidad.hackathon.project_inventory.SplashScreenActivity.mSocket;
import static com.droidad.hackathon.project_inventory.UserDetailsActivity.encodeImage;

public class AddProjectActivity extends AppCompatActivity {

    Spinner TypeSpinner, FieldSpinner;
    EditText ProjectTitleEdittext, ProjectDescriptionEdittext;
    Button AddProjectButton, ProjectDocumentButton;

    String imgDecodableString="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_project);

        TypeSpinner=(Spinner)findViewById(R.id.type_spinner);
        FieldSpinner=(Spinner)findViewById(R.id.field_spinner);
        ProjectTitleEdittext=(EditText)findViewById(R.id.project_title_edittext);
        ProjectDescriptionEdittext=(EditText)findViewById(R.id.project_description_edittext);
        AddProjectButton=(Button)findViewById(R.id.add_project_button);
        ProjectDocumentButton=(Button)findViewById(R.id.project_document_button);

        String[] TypeList={"Idea", "Project"};
        ArrayAdapter<String> TypeAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,TypeList);
        TypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        TypeSpinner.setAdapter(TypeAdapter);

        String[] FieldList={"IT", "Computer", "Mechinical", "Electrical", "Electronics & Communications", "Instrumentatio & Control"};
        final ArrayAdapter<String> FieldAdapter=new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, FieldList);
        FieldAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        FieldSpinner.setAdapter(FieldAdapter);

        ProjectDocumentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });

        AddProjectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Date= String.valueOf(Calendar.DAY_OF_MONTH);
                String Month=String.valueOf(Calendar.MONTH);
                String Year=String.valueOf(Calendar.YEAR);
                String Hour=String.valueOf(Calendar.HOUR_OF_DAY);
                String Min=String.valueOf(Calendar.MINUTE);
                final String DateTime=Date+"-"+"-"+Month+"-"+Year+" "+Hour+":"+Min;
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        mSocket.emit("projects_table_insert", userId, ProjectTitleEdittext.getText().toString().trim(), encodeImage(imgDecodableString), "Image", DateTime, FieldSpinner.getSelectedItem().toString().trim());
                        mSocket.on("projects_table_insert_response", new Emitter.Listener() {
                            @Override
                            public void call(final Object... args) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(getApplicationContext(), String.valueOf(args[0]), Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }
                        });
                    }
                }).start();




            }
        });



    }

    private void openGallery()
    {
        Intent galleryintent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(galleryintent, 1);
    }

    @Override
    protected void onActivityResult(int requestCode,int resultCode,Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK
                && null != data) {
            Uri selectedImage = data.getData();
            String[] filePathColumn = {MediaStore.Images.Media.DATA};

            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            // Move to first row
            cursor.moveToFirst();
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            imgDecodableString = cursor.getString(columnIndex);
            cursor.close();
            System.out.println("onActivityResult"+imgDecodableString);
            //sendImage(imgDecodableString);
        }
    }
}
