package com.droidad.hackathon.project_inventory;

public class IdeasListData {

    private String UserImage;
    private String UserName;
    private String ProjectName;
    private String ProjectDocument;
    private String ProjectDocumentType;
    private String IntrestedPeopleCount;

    public IdeasListData(String UserImage, String UserName, String ProjectName,
                          String  ProjectDocument, String ProjectDocumentType, String IntrestedPeopleCount){

        this.UserImage=UserImage;
        this.UserName=UserName;
        this.ProjectName=ProjectName;
        this.ProjectDocument=ProjectDocument;
        this.ProjectDocumentType=ProjectDocumentType;
        this.IntrestedPeopleCount=IntrestedPeopleCount;

    }

    public String getUserImage() {
        return UserImage;
    }

    public String getUserName() {
        return UserName;
    }

    public String getProjectName() {
        return ProjectName;
    }


    public String getProjectDocument() {
        return ProjectDocument;
    }

    public String getProjectDocumentType() {
        return ProjectDocumentType;
    }

    public String getIntrestedPeopleCount() {
        return IntrestedPeopleCount;
    }
}
