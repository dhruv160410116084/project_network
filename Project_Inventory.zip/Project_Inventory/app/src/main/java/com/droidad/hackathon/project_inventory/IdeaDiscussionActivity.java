package com.droidad.hackathon.project_inventory;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class IdeaDiscussionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_idea_discussion);
    }
}
