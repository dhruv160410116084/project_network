package com.droidad.hackathon.project_inventory;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.SearchView;
import android.widget.Toast;

import com.github.nkzawa.emitter.Emitter;

import static com.droidad.hackathon.project_inventory.SplashScreenActivity.mSocket;

public class SearchActivity extends AppCompatActivity {

    ImageButton DropdownButton, AddButton, NotificationButton, AccountButton;

    boolean dropdown_selected=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        DropdownButton=(ImageButton) findViewById(R.id.dropdown_button);
        AddButton=(ImageButton) findViewById(R.id.add_button);
        NotificationButton=(ImageButton)findViewById(R.id.notifications_button);
        AccountButton=(ImageButton)findViewById(R.id.account_button);


        DropdownButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(dropdown_selected)
                {
                    AddButton.setVisibility(View.INVISIBLE);
                    NotificationButton.setVisibility(View.INVISIBLE);
                    AccountButton.setVisibility(View.INVISIBLE);
                    dropdown_selected=false;
                }
                else
                {

                    AddButton.setVisibility(View.VISIBLE);
                    NotificationButton.setVisibility(View.VISIBLE);
                    AccountButton.setVisibility(View.VISIBLE);
                    dropdown_selected=true;

                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.search_menu, menu);

        MenuItem item = menu.findItem(R.id.search_button);
        SearchView searchView = (SearchView) item.getActionView();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                //adapter.getFilter().filter(newText);
                if (newText.isEmpty()) {
                    //ContestListView.setAdapter(contestListAdapter);
                } else {
                    //ContestListView.setFilterText(newText);
                }
                return true;
            }

        });

        searchView.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                //ContestListView.setAdapter(contestListAdapter);
                return false;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }
}
